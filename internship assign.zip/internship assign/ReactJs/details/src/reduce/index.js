import  changeId from './change'
import { combineReducers } from "redux";
const rootReducer=combineReducers({
    changeId,
})
export default rootReducer;